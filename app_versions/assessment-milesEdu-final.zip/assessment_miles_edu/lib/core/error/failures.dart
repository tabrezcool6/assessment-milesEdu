//
// This class returns a failure message which can be displayed through out the application
class Failure {
  final String message;

// default error message is written here
  Failure([this.message = 'An unexpected error occured']);
}

// display any exception message through out the application
class ServerExceptions {
  final String message;
  ServerExceptions(this.message);
}

import 'package:flutter/material.dart';

class AppPallete {
  ///
  ///
  static const Color whiteColor = Colors.white;
  static const Color blackColor = Colors.black;
  static const Color homeContinueText = Color(0xFF888888);

  static const Color primaryColor = Color(0xFF0070df);
  static const Color transparentColor = Colors.transparent;


}

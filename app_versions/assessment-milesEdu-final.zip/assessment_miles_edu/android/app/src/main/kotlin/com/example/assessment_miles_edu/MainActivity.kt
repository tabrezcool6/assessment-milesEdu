package com.example.assessment_miles_edu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
